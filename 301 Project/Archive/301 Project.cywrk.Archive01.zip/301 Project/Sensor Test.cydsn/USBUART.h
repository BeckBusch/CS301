/* ========================================
 * USBUART.h
 * ========================================
*/

#ifndef USBUART_H_
#define USBUART_H_

//void uart_code();

/* [] END OF FILE */
#endif /* USBUART_H_ */
